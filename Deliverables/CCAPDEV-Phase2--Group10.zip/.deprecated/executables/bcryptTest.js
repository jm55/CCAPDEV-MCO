import bcrypt from 'bcrypt';
const saltRounds = 10;
const salt = "8uDolF!Nd5_P@55w0Rd"

var plainTexts = ["ABCDEFG", "miguel", "manila", "momotetsu_desu"];

for(var p of plainTexts){
    
}
