console.log("printUsers.js");

// import * as utils from '../tempDB.js';
// import * as fs from 'fs';

// var filenames = ['users.json', 'posts.json', 'comments.json', 'likes.json'];

// for(var f = 0;  f < filenames.length; f++)
//   filenames[f] = './jsons/' + filenames[f];


// fs.writeFile(filenames[0], JSON.stringify(utils.users), function (err) {
//   if(err)
//     return console.log(err); 
//   console.log(filenames[0]);
// });

// fs.writeFile(filenames[1], JSON.stringify(utils.posts), function (err) {
//   if (err) return console.log(err); 
//   console.log(filenames[1]);
// });

// fs.writeFile(filenames[2], JSON.stringify(utils.comments), function (err) {
//   if (err) return console.log(err); 
//   console.log(filenames[2]);
// });

// fs.writeFile(filenames[3], JSON.stringify(utils.likes), function (err) {
//   if (err) return console.log(err); 
//   console.log(filenames[3]);
// });