# Favicons

Drop the favicon designs on this directory.

You can use https://favicon.io/favicon-converter/ to convert any image (preferrably `.png`) to favicon files.

Please do note that the filenames from the generator remain as is for it to be detected by the web application.

Do change all of the format to `.webp`