## Object Classes
This folder contains the supposed data structure of the user, post, comment, and report objects that will be used throughout the entire web application.